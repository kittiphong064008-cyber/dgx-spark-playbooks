#!/bin/bash
#
# SPDX-FileCopyrightText: Copyright (c) 1993-2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

# Setup script for txt2kg project

# Parse command line arguments
DEV_FRONTEND=false
USE_VLLM=false
USE_NEO4J=false
USE_LITELLM=false
USE_VECTOR_SEARCH=false

while [[ $# -gt 0 ]]; do
  case $1 in
    --dev-frontend)
      DEV_FRONTEND=true
      shift
      ;;
    --vllm)
      USE_VLLM=true
      shift
      ;;
    --neo4j)
      USE_NEO4J=true
      shift
      ;;
    --litellm)
      USE_LITELLM=true
      shift
      ;;
    --vector-search)
      USE_VECTOR_SEARCH=true
      shift
      ;;
    --help|-h)
      echo "Usage: ./start.sh [OPTIONS]"
      echo ""
      echo "Options:"
      echo "  --dev-frontend    Run frontend in development mode (without Docker)"
      echo "  --vllm            Use Neo4j + vLLM (GPU-accelerated, for DGX Spark/GB300)"
      echo "  --neo4j           Use Neo4j + Ollama"
      echo "  --litellm         Use Neo4j + LiteLLM (connects to external LiteLLM proxy)"
      echo "  --vector-search   Enable vector search services (Qdrant + Sentence Transformers)"
      echo "  --help, -h        Show this help message"
      echo ""
      echo "Default: Starts ArangoDB + Ollama"
      echo ""
      echo "Examples:"
      echo "  ./start.sh                       # Default: ArangoDB + Ollama"
      echo "  ./start.sh --vllm                # Use Neo4j + vLLM (GPU)"
      echo "  ./start.sh --neo4j               # Use Neo4j + Ollama"
      echo "  ./start.sh --litellm             # Use Neo4j + LiteLLM"
      echo "  ./start.sh --vector-search       # Add Qdrant + Sentence Transformers"
      echo "  ./start.sh --vllm --vector-search  # vLLM + vector search"
      echo "  ./start.sh --neo4j --vector-search # Neo4j + Ollama + vector search"
      echo "  ./start.sh --litellm --vector-search # LiteLLM + vector search"
      exit 0
      ;;
    *)
      echo "Unknown option: $1"
      echo "Run './start.sh --help' for usage information"
      exit 1
      ;;
  esac
done

# Validate mutually exclusive stack flags
STACK_FLAGS=0
[ "$USE_VLLM" = true ] && STACK_FLAGS=$((STACK_FLAGS + 1))
[ "$USE_NEO4J" = true ] && STACK_FLAGS=$((STACK_FLAGS + 1))
[ "$USE_LITELLM" = true ] && STACK_FLAGS=$((STACK_FLAGS + 1))

if [ "$STACK_FLAGS" -gt 1 ]; then
  echo "Error: --vllm, --neo4j, and --litellm select different stacks. Use only one."
  exit 1
fi

if [ "$DEV_FRONTEND" = true ]; then
  echo "Starting frontend in development mode..."
  cd frontend
  if ! command -v pnpm &> /dev/null; then
    echo "Error: pnpm is not installed. Install it with: npm install -g pnpm"
    exit 1
  fi
  pnpm run dev
  exit 0
fi

# Check for GPU support
echo "Checking for GPU support..."
if command -v nvidia-smi &> /dev/null; then
  if nvidia-smi &> /dev/null; then
    echo "✓ NVIDIA GPU detected"
    GPU_INFO=$(nvidia-smi --query-gpu=name,memory.total --format=csv,noheader | head -n1)
    echo "  GPU: $GPU_INFO"
  else
    echo "⚠ NVIDIA GPU not accessible. Services will run in CPU mode (slower)."
  fi
else
  echo "⚠ nvidia-smi not found. Services will run in CPU mode (slower)."
fi

# Check which Docker Compose version is available
DOCKER_COMPOSE_CMD=""
if docker compose version &> /dev/null; then
  DOCKER_COMPOSE_CMD="docker compose"
  echo "Using Docker Compose V2"
elif command -v docker-compose &> /dev/null; then
  DOCKER_COMPOSE_CMD="docker-compose"
  echo "Using Docker Compose V1 (deprecated - consider upgrading)"
else
  echo "Error: Neither 'docker compose' nor 'docker-compose' is available"
  echo "Please install Docker Compose: https://docs.docker.com/compose/install/"
  exit 1
fi

# Check Docker daemon permissions
echo "Checking Docker permissions..."
if ! docker info &> /dev/null; then
  echo ""
  echo "=========================================="
  echo "ERROR: Docker Permission Denied"
  echo "=========================================="
  echo ""
  echo "You don't have permission to connect to the Docker daemon."
  echo ""
  echo "To fix this, run one of the following:"
  echo ""
  echo "Option 1 (Recommended): Add your user to the docker group"
  echo "  sudo usermod -aG docker \$USER"
  echo "  newgrp docker"
  echo ""
  echo "Option 2: Run this script with sudo (not recommended)"
  echo "  sudo ./start.sh"
  echo ""
  echo "After adding yourself to the docker group, you may need to log out"
  echo "and log back in for the changes to take effect."
  echo ""
  exit 1
fi
echo "✓ Docker permissions OK"

# Select compose file and build command
COMPOSE_DIR="$(pwd)/deploy/compose"
PROFILES=""

if [ "$USE_VLLM" = true ]; then
  COMPOSE_FILE="$COMPOSE_DIR/docker-compose.vllm.yml"
  echo "Using Neo4j + vLLM (GPU-accelerated)..."
  echo "  ⚡ Optimized for DGX Spark/GB300 with unified memory support"
elif [ "$USE_LITELLM" = true ]; then
  COMPOSE_FILE="$COMPOSE_DIR/docker-compose.litellm.yml"
  echo "Using Neo4j + LiteLLM (external proxy)..."
elif [ "$USE_NEO4J" = true ]; then
  COMPOSE_FILE="$COMPOSE_DIR/docker-compose.neo4j.yml"
  echo "Using Neo4j + Ollama configuration..."
else
  COMPOSE_FILE="$COMPOSE_DIR/docker-compose.yml"
  echo "Using ArangoDB + Ollama configuration..."
fi

CMD="$DOCKER_COMPOSE_CMD -f $COMPOSE_FILE"

if [ "$USE_VECTOR_SEARCH" = true ]; then
  PROFILES="--profile vector-search"
  export VECTOR_SEARCH_ENABLED=true
  echo "Enabling vector search (Qdrant + Sentence Transformers)..."
else
  export VECTOR_SEARCH_ENABLED=false
fi

# Execute the command
echo ""
echo "Starting services..."
echo "Running: $CMD $PROFILES up -d --build"
cd $(dirname "$0")
if ! eval "$CMD $PROFILES up -d --build"; then
  echo "" >&2
  echo "ERROR: txt2kg services failed to start (image build or compose error above)." >&2
  echo "       No services are running. Fix the error and re-run ./start.sh." >&2
  exit 1
fi

# docker compose can succeed while the app container exits afterward, so confirm
# the Web UI answers before advertising it.
if command -v curl >/dev/null 2>&1; then
  WEB_UI_READY=false
  for _ in $(seq 1 30); do
    if curl -sfL http://localhost:3001 >/dev/null; then
      WEB_UI_READY=true
      break
    fi
    sleep 2
  done
  if [ "$WEB_UI_READY" != true ]; then
    echo "" >&2
    echo "ERROR: services started but the Web UI is not responding on http://localhost:3001." >&2
    echo "       Check 'docker ps' and 'docker logs compose-app-1', then re-run ./start.sh." >&2
    exit 1
  fi
fi

echo ""
echo "=========================================="
echo "txt2kg is now running!"
echo "=========================================="
echo ""
echo "Core Services:"
echo "  • Web UI: http://localhost:3001"
if [ "$USE_VLLM" = true ]; then
  echo "  • Neo4j Browser: http://localhost:7474"
  echo "  • vLLM API: http://localhost:8001 (GPU-accelerated)"
elif [ "$USE_LITELLM" = true ]; then
  echo "  • Neo4j Browser: http://localhost:7474"
  echo "  • LiteLLM Proxy: ${VLLM_BASE_URL:-http://100.93.246.21:4000/v1}"
elif [ "$USE_NEO4J" = true ]; then
  echo "  • Neo4j Browser: http://localhost:7474"
  echo "  • Ollama API: http://localhost:11434"
else
  echo "  • ArangoDB: http://localhost:8529"
  echo "  • Ollama API: http://localhost:11434"
fi
echo ""

if [ "$USE_VECTOR_SEARCH" = true ]; then
  echo "Vector Search Services:"
  echo "  • Qdrant: http://localhost:6333"
  echo "  • Sentence Transformers: http://localhost:8000"
  echo ""
else
  echo "Vector Search Services: disabled"
  echo "  • Start with --vector-search to enable Vector DB status and embedding search"
  echo ""
fi

echo "Next steps:"
if [ "$USE_VLLM" = true ]; then
  echo "  1. Wait for vLLM to load the model (check logs with: docker logs vllm-service -f)"
  echo "     Note: First startup may take several minutes to download the model"
  echo ""
  echo "  2. Open http://localhost:3001 in your browser"
else
  echo "  1. Pull an Ollama model (if not already done):"
  echo "     docker exec ollama-compose ollama pull llama3.1:8b"
  echo ""
  echo "  2. Open http://localhost:3001 in your browser"
fi
echo "  3. Upload documents and start building your knowledge graph!"
echo ""
echo "Other options:"
echo "  • Stop services: ./stop.sh"
echo "  • Run frontend in dev mode: ./start.sh --dev-frontend"
if [ "$USE_VLLM" = true ]; then
  echo "  • Use Ollama: ./start.sh (without --vllm)"
elif [ "$USE_NEO4J" = true ]; then
  echo "  • Use default ArangoDB stack: ./start.sh"
  echo "  • Use vLLM (GPU): ./start.sh --vllm"
else
  echo "  • Use vLLM (GPU): ./start.sh --vllm"
  echo "  • Use Neo4j + Ollama: ./start.sh --neo4j"
fi
echo "  • Add vector search: ./start.sh --vector-search"
echo "  • View logs: docker compose logs -f"
echo ""
